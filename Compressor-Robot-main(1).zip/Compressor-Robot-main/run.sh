python3 start.py
